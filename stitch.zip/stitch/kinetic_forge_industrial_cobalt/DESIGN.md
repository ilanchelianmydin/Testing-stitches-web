# Design System Specification: High-Tech Industrial Dark Mode

## 1. Overview & Creative North Star: "The Precision Engine"
The Creative North Star for this design system is **"The Precision Engine."** This is not a generic dashboard; it is a high-performance instrument. We are moving away from the "web-template" look by embracing a high-end editorial approach that prioritizes tonal depth over structural lines. 

The aesthetic is inspired by high-end precision machinery and aerospace interfaces. We achieve this through:
*   **Intentional Asymmetry:** Using large-scale typography and unbalanced layouts to create a dynamic, editorial feel.
*   **Tonal Architecture:** Using color shifts rather than borders to define space.
*   **The "Machined" Look:** High-contrast accents (vibrant cyan) against deep, matte charcoals to simulate backlit digital instrumentation.

---

## 2. Colors: Tonal Depth & High-Voltage Accents
Our palette avoids pure blacks, opting instead for a range of deep charcoals and slate blues to create a more sophisticated, "ink-like" dark mode.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders for sectioning or layout containment. Boundaries must be defined solely through background color shifts. For example, a `surface-container-low` section should sit directly on a `background` or `surface` area without a separating line.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Hierarchy is achieved by nesting darker containers within lighter ones, or vice versa, to simulate depth.
*   **Root Level:** `surface` (#111316)
*   **Primary Content Area:** `surface-container` (#1E2023)
*   **Elevated Widgets/Cards:** `surface-container-high` (#282A2D)
*   **Floating Navigation/Modals:** `surface-container-highest` (#333538)

### The "Glass & Gradient" Rule
To inject "soul" into the high-tech aesthetic, use semi-transparent surface colors with a `backdrop-filter: blur(20px)` for floating elements (modals, tooltips, sticky headers). 
*   **Signature Textures:** For Hero sections or primary CTAs, use a subtle linear gradient from `primary` (#C3F5FF) to `primary-container` (#00E5FF) at a 135-degree angle. This provides a "glow" that flat colors cannot replicate.

---

## 3. Typography: The Manrope Scale
Manrope is our voice: precise, modern, and highly legible. We use a wide scale to create an editorial hierarchy.

*   **Display (lg/md/sm):** Used for "Hero" moments. Use `display-lg` (3.5rem) with tight letter-spacing (-0.02em) to create an authoritative, machined feel.
*   **Headline (lg/md/sm):** Reserved for section starts. High contrast between `headline-lg` and `body-md` is essential to break the "template" look.
*   **Title (lg/md/sm):** Used for card headers and navigation. Always use Medium or Semi-Bold weights.
*   **Body (lg/md/sm):** The workhorse. `body-md` (0.875rem) in `on-surface-variant` (#BAC9CC) is the standard for long-form text to reduce eye strain.
*   **Label (md/sm):** Used for technical metadata. These should often be in ALL CAPS with +0.05em letter spacing to mimic industrial serial numbers.

---

## 4. Elevation & Depth: Atmospheric Layering
We do not use shadows to represent "height"; we use light to represent "presence."

*   **The Layering Principle:** Instead of a drop shadow, place a `surface-container-lowest` card on a `surface-container-low` background. The subtle shift from #0C0E11 to #1A1C1F creates a "recessed" look that feels engineered.
*   **Ambient Glow:** When an element must float (e.g., a primary FAB), use a shadow tinted with the `primary` color (#00DAF3) at 5% opacity, with a 32px blur. This creates a "backlit" effect rather than a "floating paper" effect.
*   **The "Ghost Border" Fallback:** If a border is required for accessibility (e.g., input fields), use the `outline-variant` (#3B494C) at **20% opacity**. Never use 100% opaque borders.

---

## 5. Components: Machined Precision

### Buttons
*   **Primary:** Solid `primary` background with `on-primary` text. No border. Radius: `md` (0.375rem).
*   **Secondary:** Ghost style. No background, `outline` border at 20% opacity. On hover, transition to `secondary-container` background.
*   **Tertiary:** Text-only using `primary-fixed-dim` (#00DAF3). Use for low-priority actions.

### Cards & Lists
*   **No Dividers:** Forbid the use of line dividers. Separate list items using 8px of vertical whitespace or a 2% shift in background color on hover.
*   **Machined Accents:** Use a 2px vertical accent bar of `primary` color on the far left of a "selected" list item to denote activity.

### Input Fields
*   **State:** Background should be `surface-container-lowest`. 
*   **Focus:** Transition the "Ghost Border" from 20% opacity to 100% using the `primary` color. Add a subtle outer glow (4px blur).

### Chips & Tags
*   **Technical Chips:** Use `secondary-container` with `on-secondary-container` text. These should feel like status indicators on a control panel.

---

## 6. Do’s and Don’ts

### Do
*   **Do** use asymmetrical margins (e.g., a wider left gutter) to create an editorial, non-standard layout.
*   **Do** use `primary` cyan sparingly. It is "power"—use it to draw the eye to a single point of intent.
*   **Do** embrace negative space. If a section feels crowded, remove a container rather than adding a border.

### Don’t
*   **Don’t** use pure black (#000000). It kills the "atmospheric" depth of the slate blue tones.
*   **Don’t** use standard Material Design shadows. They are too "organic" for this industrial system.
*   **Don’t** use "Card-on-Card" layouts where both have the same background color. Always shift the tier (e.g., High on Low).
*   **Don't** use standard 1px dividers. If you need a line, make it a "Ghost Border" (20% opacity) and ensure it doesn't touch the edges of its container.